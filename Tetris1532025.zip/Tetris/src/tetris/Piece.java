/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris;


import java.awt.Color; // Importa la clase Color para manejar colores
import java.awt.Graphics; // Importa la clase Graphics para dibujar en la pantalla
import java.util.ArrayList; // Importa la clase ArrayList para manejar listas dinámicas
import java.util.List; // Importa la interfaz List para trabajar con listas

/**
 *
 * @author pedri
 */
// Clase que representa una pieza del juego (como en Tetris)
abstract class Piece {

    private final List<Square> squares; // Lista de cuadrados que componen la pieza
    private int centerX; // Coordenada X del centro de la pieza
    private int centerY; // Coordenada Y del centro de la pieza
    private Color color; // Color de la pieza
    private static final int SQUARE_SIZE = 30; // Tamaño de cada cuadrado
    private int currentRotation = 0; // Estado actual de rotación de la pieza
    private final PieceType type; // Tipo de pieza (I, O, T, S, Z, J, L)

    // Enumeración que define los tipos de piezas
    public enum PieceType {
        I, O, T, S, Z, J, L
    }

    // Constructor de la clase Piece
    Piece(int startX, int startY, Color color) {
        this.squares = new ArrayList<>(); // Inicializa la lista de cuadrados
        this.centerX = startX; // Establece la posición inicial en X
        this.centerY = startY; // Establece la posición inicial en Y
        this.color = color; // Establece el color de la pieza
        this.type = getRandomPieceType(); // Asigna un tipo de pieza aleatorio
        createSquares(); // Crea los cuadrados que componen la pieza
    }

    // Método que devuelve un tipo de pieza aleatorio
    private PieceType getRandomPieceType() {
        PieceType[] types = PieceType.values(); // Obtiene todos los tipos de piezas
        return types[(int) (Math.random() * types.length)]; // Selecciona uno aleatoriamente
    }

    // Método que crea los cuadrados de la pieza según su tipo
    private void createSquares() {
        squares.clear(); // Limpia la lista de cuadrados
        int[][] shape = getShapeForType(); // Obtiene la forma de la pieza según su tipo

        // Crea un cuadrado para cada posición en la forma
        for (int[] pos : shape) {
            squares.add(new Square(centerX + pos[0], centerY + pos[1], color, SQUARE_SIZE));
        }
    }

    // Método que devuelve la forma de la pieza según su tipo
    private int[][] getShapeForType() {
        switch (type) {
            case I:
                color = Color.CYAN; // Color para la pieza I
                return new int[][]{{-1, 0}, {0, 0}, {1, 0}, {2, 0}}; // Forma de la pieza I
            case O:
                color = Color.YELLOW; // Color para la pieza O
                return new int[][]{{0, 0}, {1, 0}, {0, 1}, {1, 1}}; // Forma de la pieza O
            case T:
                color = Color.MAGENTA; // Color para la pieza T
                return new int[][]{{0, 0}, {-1, 0}, {1, 0}, {0, 1}}; // Forma de la pieza T
            case S:
                color = Color.GREEN; // Color para la pieza S
                return new int[][]{{0, 0}, {1, 0}, {-1, 1}, {0, 1}}; // Forma de la pieza S
            case Z:
                color = Color.RED; // Color para la pieza Z
                return new int[][]{{-1, 0}, {0, 0}, {0, 1}, {1, 1}}; // Forma de la pieza Z
            case J:
                color = Color.BLUE; // Color para la pieza J
                return new int[][]{{-1, 0}, {0, 0}, {1, 0}, {1, 1}}; // Forma de la pieza J
            case L:
                color = Color.ORANGE; // Color para la pieza L
                return new int[][]{{-1, 0}, {0, 0}, {1, 0}, {-1, 1}}; // Forma de la pieza L
            default:
                return new int[][]{{0, 0}, {1, 0}, {0, 1}, {1, 1}}; // Forma por defecto
        }
    }

    // Método para mover la pieza hacia abajo
    public void moveDown() {
        centerY++; // Aumenta la coordenada Y del centro
        squares.forEach(Square::moveDown); // Mueve cada cuadrado hacia abajo
    }

    // Método para mover la pieza hacia la izquierda
    public void moveLeft() {
        centerX--; // Disminuye la coordenada X del centro
        squares.forEach(Square::moveLeft); // Mueve cada cuadrado hacia la izquierda
    }

    // Método para mover la pieza hacia la derecha
    public void moveRight() {
        centerX++; // Aumenta la coordenada X del centro
        squares.forEach(Square::moveRight); // Mueve cada cuadrado hacia la derecha
    }

    // Método para rotar la pieza
    public void rotate() {
        if (type == PieceType.O) {
            return; // La pieza O no se puede rotar
        }
        currentRotation = (currentRotation + 1) % 4; // Incrementa la rotación actual
        List<Square> oldSquares = new ArrayList<>(squares); // Guarda la posición antigua de los cuadrados
        squares.clear(); // Limpia la lista de cuadrados

        // Rota cada cuadrado 90 grados en sentido horario
        for (Square square : oldSquares) {
            int RelX = square.getX() - centerX; // Calcula la posición relativa en X
            int RelY = square.getY() - centerY; // Calcula la posición
            // Agrega un nuevo cuadrado a la lista de cuadrados de la pieza
// La posición del nuevo cuadrado se calcula sumando las posiciones relativas (newRelX, newRelY)
// al centro de la pieza (centerX, centerY). Esto coloca el cuadrado en la posición correcta
// en el espacio del juego, utilizando el color y el tamaño de cuadrado definidos.
            squares.add(new Square(centerX + RelX, centerY + RelY, color, SQUARE_SIZE));
        }}
        // Método para dibujar la pieza en la pantalla
    public void draw(Graphics g) {
        // Itera sobre cada cuadrado en la lista de cuadrados
        squares.forEach(square -> {
            g.setColor(square.getColor()); // Establece el color del cuadrado actual
            // Dibuja un rectángulo relleno en la posición del cuadrado
            // Multiplica las coordenadas por SQUARE_SIZE para escalar a la representación gráfica
            g.fillRect(square.getX() * SQUARE_SIZE,
                    square.getY() * SQUARE_SIZE,
                    square.getSize(),
                    square.getSize());

            // Dibuja el borde del cuadrado
            g.setColor(Color.WHITE); // Establece el color del borde a blanco
            // Dibuja un rectángulo vacío (borde) en la misma posición que el cuadrado
            g.drawRect(square.getX() * SQUARE_SIZE,
                    square.getY() * SQUARE_SIZE,
                    square.getSize(),
                    square.getSize());
        });
    }

// Método que devuelve la lista de cuadrados que componen la pieza
    public List<Square> getSquares() {
        return squares; // Devuelve la lista de cuadrados
    }

// Métodos para obtener las coordenadas del centro de la pieza
    public int getCenterX() {
        return centerX;
    } // Devuelve la coordenada X del centro

    public int getCenterY() {
        return centerY;
    } // Devuelve la coordenada Y del centro

// Método para obtener el tipo de pieza
    public PieceType getType() {
        return type;
    } // Devuelve el tipo de la pieza
}

