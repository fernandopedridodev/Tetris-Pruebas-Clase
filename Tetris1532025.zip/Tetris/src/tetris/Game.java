/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris;

/**
 *
 * @author pedri
 */
import java.awt.Color; // Importa la clase Color para manejar colores
import java.awt.Graphics; // Importa la clase Graphics para dibujar en la pantalla
import java.util.ArrayList; // Importa la clase ArrayList para manejar listas dinámicas
import java.util.List; // Importa la interfaz List para trabajar con listas

// Clase que representa el juego, incluyendo la lógica del tablero y las piezas
public class Game {
    private static final int BOARD_WIDTH = 10; // Ancho del tablero
    private static final int BOARD_HEIGHT = 20; // Altura del tablero
    private boolean[][] board; // Matriz que representa el estado del tablero (true si hay una pieza)
    private Piece currentPiece; // La pieza que está actualmente en juego
    private boolean isGameOver; // Indica si el juego ha terminado
    private int score; // Puntuación del jugador
    
    // Constructor de la clase Game
    public Game() {
        board = new boolean[BOARD_HEIGHT][BOARD_WIDTH]; // Inicializa el tablero
        reset(); // Reinicia el juego
    }

    Game(MainWindow aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    // Método para reiniciar el juego
    public void reset() {
        board = new boolean[BOARD_HEIGHT][BOARD_WIDTH]; // Limpia el tablero
        isGameOver = false; // Restablece el estado de juego
        score = 0; // Reinicia la puntuación
        spawnNewPiece(); // Genera una nueva pieza
    }
    
    // Método para generar una nueva pieza en la parte superior del tablero
    private void spawnNewPiece() {
        currentPiece = new Piece(BOARD_WIDTH / 2 - 1, 0, Color.BLUE) {}; // Crea una nueva pieza en el centro superior
    }
    
    // Método para mover la pieza actual hacia la izquierda
    public void moveLeft() {
        // Verifica que el juego no haya terminado y que la pieza pueda moverse
        if (!isGameOver && canMove(currentPiece, -1, 0)) {
            currentPiece.moveLeft(); // Mueve la pieza hacia la izquierda
        }
    }
    
    // Método para mover la pieza actual hacia la derecha
    public void moveRight() {
        // Verifica que el juego no haya terminado y que la pieza pueda moverse
        if (!isGameOver && canMove(currentPiece, 1, 0)) {
            currentPiece.moveRight(); // Mueve la pieza hacia la derecha
        }
    }
    
    // Método para mover la pieza actual hacia abajo
    public void moveDown() {
        // Verifica que el juego no haya terminado
        if (!isGameOver) {
            // Si la pieza puede moverse hacia abajo, la mueve
            if (canMove(currentPiece, 0, 1)) {
                currentPiece.moveDown();
            } else {
                // Si no puede moverse, coloca la pieza en el tablero
                placePiece();
                checkLines(); // Verifica si hay líneas completas
                spawnNewPiece(); // Genera una nueva pieza
                checkGameOver(); // Verifica si el juego ha terminado
            }
        }
    }
    
    // Método para rotar la pieza actual
    public void rotate() {
        // Verifica que el juego no haya terminado
        if (!isGameOver) {
            currentPiece.rotate(); // Rota la pieza
        }
    }
    
    // Método que verifica si una pieza puede moverse a una nueva posición
    private boolean canMove(Piece piece, int deltaX, int deltaY) {
        // Itera sobre cada cuadrado de la pieza
        for (Square square : piece.getSquares()) {
            int newX = square.getX() + deltaX; // Calcula la nueva posición en X
            int newY = square.getY() + deltaY; // Calcula la nueva posición en Y
            
            // Verifica si la nueva posición está fuera de los límites o colisiona con otra pieza
            if (newX < 0 || newX >= BOARD_WIDTH || 
                newY < 0 || newY >= BOARD_HEIGHT || 
                board[newY][newX]) {
                return false; // No se puede mover
            }
        }
        return true; // Se puede mover
    }
    
    // Método para colocar la pieza actual en el tablero
    private void placePiece() {
        // Itera sobre cada cuadrado de la pieza y lo coloca en el tablero
        for (Square square : currentPiece.getSquares()) {
            board[square.getY()][square.getX()] = true; // Marca la posición en el tablero
        }
    }
    
    // Método para verificar y eliminar líneas completas en el tablero
    private void checkLines() {
        // Itera desde la parte inferior del tablero hacia arriba
        for (int row = BOARD_HEIGHT - 1; row >= 0; row--) {
            if (isLineComplete(row)) { // Verifica si la línea está completa
                removeLine(row); // Elimina la línea
                score += 100; // Aumenta la puntuación
            }
        }
    }
    
    // Método que verifica si una línea está completa
    private boolean isLineComplete(int row) {
        // Verifica cada columna en la fila especificada
        for (int col = 0; col < BOARD_WIDTH; col++) {
            if (!board[row][col]) return false; // Si hay un espacio vacío, la línea no está completa
        }
        return true; // La línea está completa
    }
    
    // Método para eliminar una línea completa y desplazar las líneas superiores hacia abajo
    private void removeLine(int row) {
        // Desplaza cada línea hacia abajo
        for (int y = row; y > 0; y--) {
            for (int x = 0; x < BOARD_WIDTH; x++) {
                board[y][x] = board[y-1][x]; // Copia la línea superior a la línea actual
            }
        }
    }
    
    // Método para verificar si el juego ha terminado
    private void checkGameOver() {
        isGameOver = !canMove(currentPiece, 0, 0); // Si no se puede mover la
    }

    void setPaused(boolean selected) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}