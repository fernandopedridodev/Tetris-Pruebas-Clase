/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris;

import java.awt.Color; // Importa la clase Color para manejar colores

/**
 *
 * @author pedri
 */
// Clase que representa un cuadrado en el juego
public class Square {

    private int x; // Coordenada X del cuadrado
    private int y; // Coordenada Y del cuadrado
    private Color color; // Color del cuadrado
    private final int size; // Tamaño del cuadrado (constante)

    // Constructor de la clase Square
    public Square(int x, int y, Color color, int size) {
        this.x = x; // Establece la coordenada X del cuadrado
        this.y = y; // Establece la coordenada Y del cuadrado
        this.color = color; // Establece el color del cuadrado
        this.size = size; // Establece el tamaño del cuadrado
    }

    // Método para obtener la coordenada X del cuadrado
    public int getX() {
        return x;
    }

    // Método para obtener la coordenada Y del cuadrado
    public int getY() {
        return y;
    }

    // Método para obtener el color del cuadrado
    public Color getColor() {
        return color;
    }

    // Método para obtener el tamaño del cuadrado
    public int getSize() {
        return size;
    }

    // Método para establecer una nueva coordenada X para el cuadrado
    public void setX(int x) {
        this.x = x;
    }

    // Método para establecer una nueva coordenada Y para el cuadrado
    public void setY(int y) {
        this.y = y;
    }

    // Método para establecer un nuevo color para el cuadrado
    public void setColor(Color color) {
        this.color = color;
    }

    // Método para mover el cuadrado hacia abajo (incrementa la coordenada Y)
    public void moveDown() {
        y++;
    }

    // Método para mover el cuadrado hacia la izquierda (decrementa la coordenada X)
    public void moveLeft() {
        x--;
    }

    // Método para mover el cuadrado hacia la derecha (incrementa la coordenada X)
    public void moveRight() {
        x++;
    }
}
