/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author fernando.pedridomarino
 */
import java.util.Scanner;
import controller.InitMenuController;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;
import persistence.PersistenceException;

public interface InitMenuView {

    // Método para mostrar o menú de inicio de sesión
    boolean showLoginMenu();

    // Método para mostrar un erro de inicio de sesión
    void showLoginErrorMessage();

    // Método para mostrar un erro de conexión
    void showConnectionErrorMessage();

    // Método para mostrar un erro de lectura de datos
    void showReadErrorMessage();

    // Método para mostrar un erro de escritura de datos
    void showWriteErrorMessage();

    // Método para mostrar o menú de novo nome
    String showNewNameMenu();

    // Método para mostrar o menú de rexistro
    void showRegisterMenu();
}