/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

import java.util.ArrayList;
import java.util.Collection;
import model.Profile;

/**
 *
 * @author fernando.pedridomarino
 */
public class TacebookDB {

    public static Collection<Profile> profiles = new ArrayList<>();

    public void guardarPerfil(String nombre, String contrasinal, String estado) throws Exception {
        throw new Exception("Erro ao gardar o perfil na base de datos.");
    }

    public void cargarPerfil(String nombre) throws Exception {
        throw new Exception("Erro ao cargar o perfil da base de datos.");
    }

    public void eliminarPerfil(String nombre) throws Exception {
        throw new Exception("Erro ao eliminar o perfil da base de datos.");
    }

    
      /**
     * Método para pechar a conexión coa base de datos.
     * Actualmente non fai nada, pero se pode ampliar no futuro.
     */
    public static void close() {
        // De momento non se implementa nada aquí
        // Pero cando se precise, esta función poderá pechar as conexións abertas
    }
}
