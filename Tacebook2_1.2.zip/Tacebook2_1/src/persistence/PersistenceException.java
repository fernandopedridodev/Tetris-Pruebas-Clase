/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

/**
 *
 * @author pedri
 */
public class PersistenceException extends Exception{
    
    // Atributo para almacenar o código do erro
    private int code;

    // Constantes para os diferentes tipos de erro
    public static final int CONNECTION_ERROR = 0;
    public static final int CANNOT_READ = 1;
    public static final int CANNOT_WRITE = 2;

    // Constructor que recibe o código e o mensaje
    public PersistenceException(int code, String message) {
        super(message); // Chama ao constructor da superclase Exception
        this.code = code;
    }

    // Método para obter o código do erro
    public int getCode() {
        return code;
    }

    // Método para establecer o código do erro (opcional, se precisas modificar o código)
    public void setCode(int code) {
        this.code = code;
    }
}
