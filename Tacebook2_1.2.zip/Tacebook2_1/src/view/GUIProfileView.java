/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.Profile;

/**
 *
 * @author fernando.pedridomarino
 */
public class GUIProfileView implements ProfileView{
     @Override
    public int getPostsShowed() {
        return 10; // Exemplo de número de publicacións amosadas
    }

    @Override
    public void showProfileMenu(Profile profile) {
        System.out.println("=== MENÚ DO PERFIL - Versión GUI ===");
        System.out.println("Nome: " + profile.getName());
        System.out.println("Estado: " + profile.getStatus());
    }

    @Override
    public void showProfileNotFoundMessage() {
        System.out.println("Erro: O perfil non foi atopado. [Versión GUI]");
    }

    @Override
    public void showCannotLikeOwnPostMessage() {
        System.out.println("Non podes dar 'gústame' ás túas propias publicacións. [Versión GUI]");
    }

    @Override
    public void showAlreadyLikedPostMessage() {
        System.out.println("Xa gustaches esta publicación. [Versión GUI]");
    }

    @Override
    public void showIsAlreadyFriendMessage(String profileName) {
        System.out.println("Xa es amigo de " + profileName + ". [Versión GUI]");
    }

    @Override
    public void showExistsFrienshipRequestMessage(String profileName) {
        System.out.println("Xa existe unha solicitude de amizade para " + profileName + ". [Versión GUI]");
    }

    @Override
    public void showDuplicateFrienshipRequestMessage(String profileName) {
        System.out.println("Xa enviaste unha solicitude de amizade a " + profileName + ". [Versión GUI]");
    }

    @Override
    public void showConnectionErrorMessage() {
        System.out.println("Erro de conexión coa base de datos. [Versión GUI]");
    }

    @Override
    public void showReadErrorMessage() {
        System.out.println("Erro ao ler os datos. [Versión GUI]");
    }

    @Override
    public void showWriteErrorMessage() {
        System.out.println("Erro ao escribir os datos. [Versión GUI]");
    }
}
