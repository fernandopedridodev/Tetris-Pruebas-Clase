/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Profile;
import persistence.PersistenceException;
import view.ProfileView;
import persistence.ProfileDB;
import view.GUIProfileView;
import view.TextProfileView;

/**
 *
 * @author fernando.pedridomarino
 */
public class ProfileController {
     private boolean textMode;
    private ProfileView view;

    public ProfileController(boolean textMode) {
        this.textMode = textMode;

        if (textMode) {
            this.view = new TextProfileView();
        } else {
            this.view = new GUIProfileView();
        }
    }

    public ProfileController() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void showProfile(Profile profile) {
        view.showProfileMenu(profile);
    }

    public void deleteProfile() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateProfileName(String newName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void openSession(Profile profile) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

}
