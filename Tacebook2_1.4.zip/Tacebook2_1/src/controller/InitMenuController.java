/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Profile;
import persistence.PersistenceException;
import view.InitMenuView;
import persistence.ProfileDB;
import persistence.TacebookDB;
import view.InitMenuGUIView;
import view.ViewInterface;

/**
 *
 * @author fernando.pedridomarino
 */
public class InitMenuController {
   private boolean textMode;
    private InitMenuView view;

    public InitMenuController(boolean textMode) {
        this.textMode = textMode;

        if (textMode) {
            this.view = new InitMenuViewImpl(this);
        } else {
            this.view = (InitMenuView) new InitMenuGUIView(this);
        }
    }

    public void start() {
        boolean loggedIn = view.showLoginMenu();
        if (!loggedIn) {
            view.showLoginErrorMessage();
        }
    }

    public static void main(String[] args) {
        boolean textMode = false;

        if (args.length > 0 && args[0].equalsIgnoreCase("text")) {
            textMode = true;
        }

        InitMenuController controller = new InitMenuController(textMode);
        controller.start();

        // Chamamos ao método close() antes de que remate o programa
        TacebookDB.close();
    }

    private static class InitMenuViewImpl implements InitMenuView {

        public InitMenuViewImpl(InitMenuController aThis) {
        }

        @Override
        public boolean showLoginMenu() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public void showLoginErrorMessage() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public void showConnectionErrorMessage() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public void showReadErrorMessage() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public void showWriteErrorMessage() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public String showNewNameMenu() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        @Override
        public void showRegisterMenu() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
 

}

