/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

import persistence.TacebookDB;
import model.Profile;

/**
 *
 * @author fernando.pedridomarino
 */
public class ProfileDB {

   public static Profile findByName(String name) throws Exception {
        try {
            for (Profile profile : TacebookDB.profiles) {
                if (profile.getName().equals(name)) {
                    return profile;
                }
            }
            return null;
        } catch (Exception e) {
            throw new Exception("Erro ao buscar o perfil na base de datos.");
        }
    }

    public static Profile findByNameAndPassword(String name, String password) throws Exception {
        try {
            for (Profile profile : TacebookDB.profiles) {
                if (profile.getName().equals(name) && profile.getPassword().equals(password)) {
                    return profile;
                }
            }
            return null;
        } catch (Exception e) {
            throw new Exception("Erro ao buscar o perfil con nome e contrasinal na base de datos.");
        }
    }

    public static void save(Profile profile) throws Exception {
        try {
            TacebookDB.profiles.add(profile);
        } catch (Exception e) {
            throw new Exception("Erro ao gardar o perfil na base de datos.");
        }
    }

    public static void update(Profile profile) throws Exception {
        try {
            // De momento non fai nada, pero no futuro actualizará o perfil na base de datos
        } catch (Exception e) {
            throw new Exception("Erro ao actualizar o perfil na base de datos.");
        }
    }

    public static void cerrarConexion() {
        // De momento no hace nada, pero en el futuro cerrará la conexión con la base de datos
        System.out.println("Pechar conexión coa base de datos.");
    }

}
