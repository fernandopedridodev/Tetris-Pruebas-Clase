/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author fernando.pedridomarino
 */
import java.util.Scanner;
import model.Profile;
import controller.ProfileController;
import java.util.NoSuchElementException;
import persistence.PersistenceException;

public interface ProfileView {

    // Método para obter o número de publicacións amosadas
    int getPostsShowed();

    // Método para mostrar o menú do perfil
    void showProfileMenu(Profile profile);

    // Método para mostrar un erro cando non se atopa o perfil
    void showProfileNotFoundMessage();

    // Método para mostrar un erro cando un usuario intenta gustar a súa propia publicación
    void showCannotLikeOwnPostMessage();

    // Método para mostrar un erro cando un usuario tenta gustar unha publicación que xa gustou
    void showAlreadyLikedPostMessage();

    // Método para mostrar un erro cando un usuario tenta ser amigo de alguén co que xa é amigo
    void showIsAlreadyFriendMessage(String profileName);

    // Método para mostrar un erro cando xa existe unha solicitude de amizade
    void showExistsFrienshipRequestMessage(String profileName);

    // Método para mostrar un erro cando se intenta facer unha solicitude de amizade duplicada
    void showDuplicateFrienshipRequestMessage(String profileName);

    // Método para mostrar un erro de conexión
    void showConnectionErrorMessage();

    // Método para mostrar un erro de lectura
    void showReadErrorMessage();

    // Método para mostrar un erro de escritura
    void showWriteErrorMessage();
}