/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Profile;
import persistence.PersistenceException;
import view.ProfileView;
import persistence.ProfileDB;

/**
 *
 * @author fernando.pedridomarino
 */
public class ProfileController {
 private ProfileView profileView;
    private Profile sessionProfile;

    // Constructor
    public ProfileController() {
        this.profileView = new ProfileView(this);
    }

    // Obtener el perfil de la sesión
    public Profile getSessionProfile() {
        return sessionProfile;
    }

    // Abrir sesión con un perfil
    public void openSession(Profile sessionProfile) {
        this.sessionProfile = sessionProfile;
        profileView.showProfileMenu(sessionProfile);
    }

    // Actualizar el estado del perfil
    public void updateProfileStatus(String newStatus) {
        try {
            // Actualizar el estado en el perfil
            sessionProfile.setStatus(newStatus);

            // Intentar guardar el perfil actualizado en la base de datos
            ProfileDB.update(sessionProfile);

            // Recargar el perfil después de la actualización
            reloadProfile();
        } catch (PersistenceException ex) {
            // Procesar la excepción de persistencia
            processPersistenceException(ex);
        }
    }

    // Recargar el perfil mostrando el menú
    public void reloadProfile() {
        profileView.showProfileMenu(sessionProfile);
    }

    // Obtener el número de publicaciones mostradas
    public int getPostsShowed() {
        return profileView.getPostsShowed();
    }

    // Eliminar el perfil (aún no implementado)
    public void deleteProfile() {
        try {
            // Intentar eliminar el perfil de la base de datos (simulación)
            ProfileDB.delete(sessionProfile);
            // Recargar el perfil si la eliminación es exitosa
            reloadProfile();
        } catch (PersistenceException ex) {
            // Procesar la excepción de persistencia
            processPersistenceException(ex);
        }
    }

    // Actualizar el nombre del perfil (aún no implementado)
    public void updateProfileName(String newName) throws Exception {
        try {
            // Intentar actualizar el nombre en el perfil
            sessionProfile.setName(newName);
            ProfileDB.update(sessionProfile);
            // Recargar el perfil después de la actualización
            reloadProfile();
        } catch (PersistenceException ex) {
            // Procesar la excepción de persistencia
            processPersistenceException(ex);
        }
    }

    // Método para procesar excepciones de persistencia
    private void processPersistenceException(PersistenceException ex) {
        // Dependiendo del código de la excepción, llamar al método correspondiente en la vista
        switch (ex.getCode()) {
            case PersistenceException.CONNECTION_ERROR:
                profileView.showConnectionErrorMessage();
                break;
            case PersistenceException.CANNOT_READ:
                profileView.showReadErrorMessage();
                break;
            case PersistenceException.CANNOT_WRITE:
                profileView.showWriteErrorMessage();
                break;
            default:
                System.out.println("Error desconocido en la persistencia.");
        }
    }

}
