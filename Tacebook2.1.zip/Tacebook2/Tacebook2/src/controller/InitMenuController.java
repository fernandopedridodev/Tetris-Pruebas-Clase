/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Profile;
import persistence.PersistenceException;
import view.InitMenuView;
import persistence.ProfileDB;
import persistence.TacebookDB;
import view.InitMenuGUIView;
import view.ViewInterface;

/**
 *
 * @author fernando.pedridomarino
 */
public class InitMenuController {

    private InitMenuView initMenuView;

    // Constructor
    public InitMenuController() {
        this.initMenuView = new InitMenuView(this);
    }

    // Método para iniciar el menú
    public void init() {
        boolean exit = false;

        while (!exit) {
            exit = initMenuView.showLoginMenu();
        }
    }

    // Método para realizar login
    public void login(String name, String password) {
        try {
            Profile profile = ProfileDB.findByNameAndPassword(name, password);

            if (profile == null) {
                initMenuView.showLoginErrorMessage();
            } else {
                ProfileController profileController = new ProfileController();
                profileController.openSession(profile);
            }
        } catch (PersistenceException ex) {
            processPersistenceException(ex);
        }
    }

    // Método para crear un perfil
    public void createProfile(String name, String password, String status) {
        try {
            if (ProfileDB.findByName(name) != null) {
                String newName = initMenuView.showNewNameMenu();
                createProfile(newName, password, status);
            } else {
                Profile profile = new Profile(name, password, status);
                ProfileDB.save(profile);
                ProfileController profileController = new ProfileController();
                profileController.openSession(profile);
            }
        } catch (PersistenceException ex) {
            processPersistenceException(ex);
        }
    }

    // Método principal para iniciar la aplicación
    public static void main(String[] args) {
        InitMenuController controller = new InitMenuController();
        ViewInterface view;

        // Verificar si el parámetro "text" está presente para usar la vista de texto
        if (args.length > 0 && args[0].equals("text")) {
            view = new InitMenuView(controller); // Vista de texto
        } else {
            view = new InitMenuGUIView(controller); // Vista gráfica
        }

        // Bucle principal: se ejecuta hasta que el usuario decida salir
        while (!view.showLoginMenu()) {
            // Continuar mostrando el menú hasta que el usuario seleccione "Saír"
        }
         TacebookDB.close();
    }

    // Método para procesar excepciones de persistencia
    private void processPersistenceException(PersistenceException ex) {
        // Dependiendo del código de la excepción, llamar al método correspondiente en la vista
        switch (ex.getCode()) {
            case PersistenceException.CONNECTION_ERROR:
                initMenuView.showConnectionErrorMessage();
                break;
            case PersistenceException.CANNOT_READ:
                initMenuView.showReadErrorMessage();
                break;
            case PersistenceException.CANNOT_WRITE:
                initMenuView.showWriteErrorMessage();
                break;
            default:
                System.out.println("Error desconocido en la persistencia.");
        }
    }
}

