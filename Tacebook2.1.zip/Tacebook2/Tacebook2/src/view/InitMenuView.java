/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author fernando.pedridomarino
 */
import java.util.Scanner;
import controller.InitMenuController;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;
import persistence.PersistenceException;

public class InitMenuView implements ViewInterface{
 
    private InitMenuController initMenuController;

    public InitMenuView(InitMenuController initMenuController) {
        this.initMenuController = initMenuController;
    }

    public boolean showLoginMenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Iniciar sesión");
        System.out.println("2. Crear un novo perfil");
        System.out.println("3. Saír");
        System.out.print("Seleccione unha opción: ");

        int option = readNumber(scanner);  // Usamos el método readNumber para leer la opción

        scanner.nextLine(); // Limpiar el buffer

        try {
            switch (option) {
                case 1:
                    System.out.print("Nome de usuario: ");
                    String name = scanner.nextLine();
                    System.out.print("Contrasinal: ");
                    String password = scanner.nextLine();
                    initMenuController.login(name, password);
                    break;
                case 2:
                    showRegisterMenu();
                    break;
                case 3:
                    return true; // Salir de la aplicación
                default:
                    System.out.println("Opción non válida.");
            }
        } catch (PersistenceException e) {
            handlePersistenceException(e);  // Capturamos y manejamos la excepción
        } catch (Exception ex) {
            Logger.getLogger(InitMenuView.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false; // No se ha salido
    }

    public void showLoginErrorMessage() {
        System.out.println("Usuario ou contrasinal incorrectos.");
    }

    public void showRegisterMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nome de usuario: ");
        String name = scanner.nextLine();
        System.out.print("Contrasinal: ");
        String password = scanner.nextLine();
        System.out.print("Repita o contrasinal: ");
        String confirmPassword = scanner.nextLine();
        System.out.print("Estado: ");
        String status = scanner.nextLine();

        if (!password.equals(confirmPassword)) {
            System.out.println("Os contrasinais non coinciden.");
            return;
        }

        try {
            initMenuController.createProfile(name, password, status);
        } catch (PersistenceException e) {
            handlePersistenceException(e);  // Capturamos y manejamos la excepción
        } catch (Exception ex) {
            Logger.getLogger(InitMenuView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Método que lee un número y maneja la excepción de entrada no válida
    private int readNumber(Scanner scanner) {
        while (true) {
            try {
                return scanner.nextInt();  // Intentamos leer un número
            } catch (java.util.InputMismatchException e) {
                System.out.println("Por favor, introduce un número válido.");
                scanner.nextLine(); // Limpiar el buffer
            }
        }
    }

    // Métodos para mostrar los mensajes de error
    public void showConnectionErrorMessage() {
        System.out.println("Erro na conexión co almacén de datos!");
    }

    public void showReadErrorMessage() {
        System.out.println("Erro na lectura de datos!");
    }

    public void showWriteErrorMessage() {
        System.out.println("Erro na escritura dos datos!");
    }

    // Método para manejar las excepciones de persistencia
    private void handlePersistenceException(PersistenceException e) {
        switch (e.getCode()) {
            case PersistenceException.CONNECTION_ERROR:
                showConnectionErrorMessage();
                break;
            case PersistenceException.CANNOT_READ:
                showReadErrorMessage();
                break;
            case PersistenceException.CANNOT_WRITE:
                showWriteErrorMessage();
                break;
            default:
                System.out.println("Erro descoñecido na persistencia.");
        }
    }

    @Override
    public String showNewNameMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}