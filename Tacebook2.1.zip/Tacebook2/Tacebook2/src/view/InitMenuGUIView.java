/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.InitMenuController;
import javax.swing.JOptionPane;

/**
 *
 * @author pedri
 */
public class InitMenuGUIView implements ViewInterface{
     private InitMenuController initMenuController;

    // Constructor que recibe el controlador
    public InitMenuGUIView(InitMenuController initMenuController) {
        this.initMenuController = initMenuController;
    }

    // Implementación del menú de inicio de sesión en GUI
    @Override
    public boolean showLoginMenu() {
        String[] options = {"Iniciar sesión", "Crear un novo perfil", "Saír"};
        
        // Mostrar las opciones con JOptionPane
        int option = JOptionPane.showOptionDialog(null, "Seleccione unha opción:", "Menú de inicio",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        // Acciones según la opción seleccionada
        switch (option) {
            case 0:
                String name = JOptionPane.showInputDialog("Nome de usuario:");
                String password = JOptionPane.showInputDialog("Contrasinal:");
                initMenuController.login(name, password);
                break;
            case 1:
                showRegisterMenu();
                break;
            case 2:
                return true; // Salir de la aplicación
        }
        return false;
    }

    // Mostrar mensaje de error de inicio de sesión
    @Override
    public void showLoginErrorMessage() {
        JOptionPane.showMessageDialog(null, "Usuario ou contrasinal incorrectos.\nVersión GUI", "Erro", JOptionPane.ERROR_MESSAGE);
    }

    // Implementación del menú de registro en GUI
    @Override
    public void showRegisterMenu() {
        String name = JOptionPane.showInputDialog("Nome de usuario:");
        String password = JOptionPane.showInputDialog("Contrasinal:");
        String confirmPassword = JOptionPane.showInputDialog("Repita o contrasinal:");
        String status = JOptionPane.showInputDialog("Estado:");

        // Validar que las contraseñas coincidan
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(null, "Os contrasinais non coinciden.\nVersión GUI", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // Llamada al controlador para crear el perfil
        initMenuController.createProfile(name, password, status);
    }

    // Mostrar mensaje pidiendo un nuevo nombre de usuario
    @Override
    public String showNewNameMenu() {
        return JOptionPane.showInputDialog("O nome de usuario introducido xa estaba en uso.\nIntroduza un novo nome: \nVersión GUI");
    }
}
